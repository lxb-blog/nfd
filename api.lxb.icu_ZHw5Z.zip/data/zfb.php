<?php
// 设置要跳转的URL
$url = "https://qr.alipay.com/11w153519mn9yoihfdz27b4";

// 使用header函数进行跳转
header("Location: $url");
exit(); // 确保脚本在跳转后终止